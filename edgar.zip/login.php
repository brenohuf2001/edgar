<?php
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "Empresa";

// Cria conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

$userType = $_POST['userType'];
$login = $_POST['username'];
$senha = $_POST['password'];

if ($userType == 'buyer') {
    $stmt = $conn->prepare("SELECT Senha FROM Clientes WHERE Login = ?");
} else if ($userType == 'seller') {
    $stmt = $conn->prepare("SELECT Senha FROM Vendedores WHERE Login = ?");
}

$stmt->bind_param("s", $login);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    $stmt->bind_result($hashed_password);
    $stmt->fetch();

    if (password_verify($senha, $hashed_password)) {
        // Login bem-sucedido
        if ($userType == 'buyer') {
            header("Location: scomprador.html");
        } else {
            header("Location: svendedor.html");
        }
        exit();
    } else {
        // Senha incorreta
        $message = "Senha incorreta.";
    }
} else {
    // Usuário não encontrado
    $message = "Usuário não encontrado.";
}

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ReuserMark - Login</title>
<style>
    body {
        font-family: Arial, sans-serif;
        text-align: center;
        background-color: #f8f9fa;
        margin: 0;
        padding: 0;
    }
    .container {
        margin: 50px auto;
        width: 300px;
        padding: 20px;
        background-color: #fff;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        border-radius: 10px;
    }
    input {
        width: 100%;
        padding: 10px;
        margin: 5px 0;
        box-sizing: border-box;
    }
    button {
        background-color: #4CAF50;
        color: white;
        padding: 10px 20px;
        margin: 8px 0;
        border: none;
        cursor: pointer;
        width: 100%;
    }
    button.register {
        background-color: #007bff;
    }
    .message {
        color: red;
        margin-top: 10px;
    }
</style>
</head>
<body>
    <h1>Welcome to ReuserMark</h1>
    <div class="container">
        <form id="loginForm" action="login.php" method="post">
            <input type="text" id="username" name="username" placeholder="Username" required>
            <input type="password" id="password" name="password" placeholder="Password" required>
            <input type="hidden" id="userType" name="userType" value="">
            <button type="button" onclick="setUserTypeAndSubmit('buyer')">Login como comprador</button>
            <button type="button" onclick="setUserTypeAndSubmit('seller')">Login como vendedor</button>
            <button type="button" class="register" onclick="redirectToRegister()">Cadastrar</button>
            <div id="message" class="message"><?php echo isset($message) ? $message : ''; ?></div>
        </form>
    </div>

    <script>
        function setUserTypeAndSubmit(userType) {
            document.getElementById('userType').value = userType;
            document.getElementById('loginForm').submit();
        }

        function redirectToRegister() {
            window.location.href = 'registro.html';
        }
    </script>
</body>
</html>
