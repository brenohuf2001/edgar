<?php
session_start(); // Certifique-se de que a sessão esteja iniciada
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "Empresa";

// Cria conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Supondo que o ID do usuário esteja armazenado na sessão
$userID = $_SESSION['userID'];
$userType = $_SESSION['userType']; // 'buyer' ou 'seller'

if ($userType == 'buyer') {
    $stmt = $conn->prepare("SELECT NomeCliente, CPF, Login, Email FROM Clientes WHERE id = ?");
} else if ($userType == 'seller') {
    $stmt = $conn->prepare("SELECT NomeVendedor, CPF, Login, Email FROM Vendedores WHERE id = ?");
}

$stmt->bind_param("i", $userID);
$stmt->execute();
$result = $stmt->get_result();
$userData = $result->fetch_assoc();
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Perfil do Usuário</title>
<style>
    body {
        font-family: Arial, sans-serif;
        text-align: center;
        background-color: #f8f9fa;
        margin: 0;
        padding: 0;
    }
    .container {
        margin: 50px auto;
        width: 300px;
        padding: 20px;
        background-color: #fff;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        border-radius: 10px;
    }
    .info {
        margin: 10px 0;
        font-size: 18px;
    }
    button {
        background-color: #007bff;
        color: white;
        padding: 10px 20px;
        margin: 8px 0;
        border: none;
        cursor: pointer;
        width: 100%;
    }
</style>
</head>
<body>
    <h1>Perfil do Usuário</h1>
    <div class="container">
        <div class="info">Nome: <?php echo htmlspecialchars($userData['NomeCliente'] ?? $userData['NomeVendedor']); ?></div>
        <div class="info">CPF: <?php echo htmlspecialchars($userData['CPF']); ?></div>
        <div class="info">Login: <?php echo htmlspecialchars($userData['Login']); ?></div>
        <div class="info">Email: <?php echo htmlspecialchars($userData['Email']); ?></div>
        <button onclick="window.location.href='editar_perfil.php'">Editar Perfil</button>
    </div>
</body>
</html>
