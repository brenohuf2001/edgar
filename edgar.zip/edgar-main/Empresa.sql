-- Criação do banco de dados
CREATE DATABASE IF NOT EXISTS Empresa;

-- Seleção do banco de dados
USE Empresa;

-- Criação da tabela Vendedores
CREATE TABLE Vendedores (
    ID INT AUTO_INCREMENT PRIMARY KEY,
    NomeVendedor VARCHAR(255) NOT NULL,
    CPF VARCHAR(14) NOT NULL,
    Login VARCHAR(255) NOT NULL,
    Senha VARCHAR(255) NOT NULL,
    InformacoesRecebimento TEXT
);

-- Criação da tabela Clientes
CREATE TABLE Clientes (
    ID INT AUTO_INCREMENT PRIMARY KEY,
    NomeCliente VARCHAR(255) NOT NULL,
    CPF VARCHAR(14) NOT NULL,
    Login VARCHAR(255) NOT NULL,
    Senha VARCHAR(255) NOT NULL,
    InformacoesCompra TEXT
);

-- Criação da tabela Produtos
CREATE TABLE Produtos (
    ID INT AUTO_INCREMENT PRIMARY KEY,
    VendedorID INT NOT NULL,
    NomeProduto VARCHAR(255) NOT NULL,
    MarcaProduto VARCHAR(255),
    DataFabricacao DATE,
    ModeloProduto VARCHAR(255),
    ReservadoPorCliente VARCHAR(255),
    PrecoProduto DECIMAL(10, 2),
    LocalizacaoProduto VARCHAR(255),
    FOREIGN KEY (VendedorID) REFERENCES Vendedores(ID)
);

-- Criação da tabela Categorias
CREATE TABLE Categorias (
    ID INT AUTO_INCREMENT PRIMARY KEY,
    NomeCategoria VARCHAR(255) NOT NULL
);

-- Criação da tabela de junção ProdutoCategorias
CREATE TABLE ProdutoCategorias (
    ProdutoID INT NOT NULL,
    CategoriaID INT NOT NULL,
    PRIMARY KEY (ProdutoID, CategoriaID),
    FOREIGN KEY (ProdutoID) REFERENCES Produtos(ID),
    FOREIGN KEY (CategoriaID) REFERENCES Categorias(ID)
);

-- Criação da tabela Serviços
CREATE TABLE Servicos (
    ID INT AUTO_INCREMENT PRIMARY KEY,
    VendedorID INT NOT NULL,
    NomeServico VARCHAR(255) NOT NULL,
    TempoServico TIME,
    ReservadoPorCliente VARCHAR(255),
    PrecoServico DECIMAL(10, 2),
    LocalizacaoServico VARCHAR(255),
    FOREIGN KEY (VendedorID) REFERENCES Vendedores(ID)
);

-- Criação da tabela de junção ServicoCategorias
CREATE TABLE ServicoCategorias (
    ServicoID INT NOT NULL,
    CategoriaID INT NOT NULL,
    PRIMARY KEY (ServicoID, CategoriaID),
    FOREIGN KEY (ServicoID) REFERENCES Servicos(ID),
    FOREIGN KEY (CategoriaID) REFERENCES Categorias(ID)
);

-- Criação da tabela Enderecos
CREATE TABLE Enderecos (
    ID INT AUTO_INCREMENT PRIMARY KEY,
    Endereco VARCHAR(255) NOT NULL
);

-- Criação da tabela de junção ClienteEnderecos
CREATE TABLE ClienteEnderecos (
    ClienteID INT NOT NULL,
    EnderecoID INT NOT NULL,
    PRIMARY KEY (ClienteID, EnderecoID),
    FOREIGN KEY (ClienteID) REFERENCES Clientes(ID),
    FOREIGN KEY (EnderecoID) REFERENCES Enderecos(ID)
);

-- Criação da tabela de junção VendedorEnderecos
CREATE TABLE VendedorEnderecos (
    VendedorID INT NOT NULL,
    EnderecoID INT NOT NULL,
    PRIMARY KEY (VendedorID, EnderecoID),
    FOREIGN KEY (VendedorID) REFERENCES Vendedores(ID),
    FOREIGN KEY (EnderecoID) REFERENCES Enderecos(ID)
);

-- Criação da tabela Administradores
CREATE TABLE Administradores (
    ID INT AUTO_INCREMENT PRIMARY KEY,
    NomeAdministrador VARCHAR(255) NOT NULL,
    CPF VARCHAR(14) NOT NULL,
    Login VARCHAR(255) NOT NULL,
    Senha VARCHAR(255) NOT NULL,
    NivelAcesso INT
);