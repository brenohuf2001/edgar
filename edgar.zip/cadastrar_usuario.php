<?php
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "Empresa";

// Cria conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

$userType = $_POST['userType'];
$nome = $_POST['nome_cliente'];
$cpf = $_POST['cpf_cliente'];
$login = $_POST['login_cliente'];
$senha = password_hash($_POST['senha_cliente'], PASSWORD_DEFAULT); // Armazena a senha de forma segura
$email = $_POST['email_cliente'];

if ($userType == 'buyer') {
    $stmt = $conn->prepare("INSERT INTO Clientes (NomeCliente, CPF, Login, Senha, Email) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $nome, $cpf, $login, $senha, $email);
    $userRole = "cliente";
} else if ($userType == 'seller') {
    $endereco = ""; // Supondo que o endereço seja opcional ou adicionado posteriormente
    $informacoes_recebimento = ""; // Supondo que as informações de recebimento sejam opcionais ou adicionadas posteriormente
    $stmt = $conn->prepare("INSERT INTO Vendedores (NomeVendedor, CPF, Login, Senha, Email) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssss", $nome, $cpf, $login, $senha, $email);
    $userRole = "vendedor";
}

if ($stmt->execute()) {
    echo "Novo $userRole cadastrado com sucesso!";
} else {
    echo "Erro: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
