<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "Empresa";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

$userID = $_SESSION['userID'];
$userType = $_SESSION['userType'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = $_POST['nome_cliente'];
    $cpf = $_POST['cpf_cliente'];
    $login = $_POST['login_cliente'];
    $email = $_POST['email_cliente'];
    
    if ($userType == 'buyer') {
        $stmt = $conn->prepare("UPDATE Clientes SET NomeCliente=?, CPF=?, Login=?, Email=? WHERE id=?");
        $stmt->bind_param("ssssi", $nome, $cpf, $login, $email, $userID);
    } else if ($userType == 'seller') {
        $stmt = $conn->prepare("UPDATE Vendedores SET NomeVendedor=?, CPF=?, Login=?, Email=? WHERE id=?");
        $stmt->bind_param("ssssi", $nome, $cpf, $login, $email, $userID);
    }

    if ($stmt->execute()) {
        header("Location: perfil_usuario.php");
        exit();
    } else {
        echo "Erro: " . $stmt->error;
    }

    $stmt->close();
}

if ($userType == 'buyer') {
    $stmt = $conn->prepare("SELECT NomeCliente, CPF, Login, Email FROM Clientes WHERE id = ?");
} else if ($userType == 'seller') {
    $stmt = $conn->prepare("SELECT NomeVendedor, CPF, Login, Email FROM Vendedores WHERE id = ?");
}

$stmt->bind_param("i", $userID);
$stmt->execute();
$result = $stmt->get_result();
$userData = $result->fetch_assoc();
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Editar Perfil</title>
<style>
    body {
        font-family: Arial, sans-serif;
        text-align: center;
        background-color: #f8f9fa;
        margin: 0;
        padding: 0;
    }
    .container {
        margin: 50px auto;
        width: 300px;
        padding: 20px;
        background-color: #fff;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        border-radius: 10px;
    }
    input {
        width: 100%;
        padding: 10px;
        margin: 5px 0;
        box-sizing: border-box;
    }
    button {
        background-color: #4CAF50;
        color: white;
        padding: 10px 20px;
        margin: 8px 0;
        border: none;
        cursor: pointer;
        width: 100%;
    }
</style>
</head>
<body>
    <h1>Editar Perfil</h1>
    <div class="container">
        <form action="editar_perfil.php" method="post">
            <input type="text" id="nome_cliente" name="nome_cliente" value="<?php echo htmlspecialchars($userData['NomeCliente'] ?? $userData['NomeVendedor']); ?>" required>
            <input type="text" id="cpf_cliente" name="cpf_cliente" value="<?php echo htmlspecialchars($userData['CPF']); ?>" required>
            <input type="text" id="login_cliente" name="login_cliente" value="<?php echo htmlspecialchars($userData['Login']); ?>" required>
            <input type="email" id="email_cliente" name="email_cliente" value="<?php echo htmlspecialchars($userData['Email']); ?>" required>
            <button type="submit">Salvar</button>
        </form>
    </div>
</body>
</html>
